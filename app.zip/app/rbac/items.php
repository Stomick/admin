<?php
return [
    'user' => [
        'type' => 1,
        'ruleName' => 'userRole',
    ],
    'admin' => [
        'type' => 1,
        'ruleName' => 'userRole',
    ],
    'super-admin' => [
        'type' => 1,
        'ruleName' => 'userRole',
    ],
];
