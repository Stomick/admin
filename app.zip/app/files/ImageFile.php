<?php

namespace app\files;

/**
 * ImageFile is base class for images.
 */
class ImageFile extends File
{
}
