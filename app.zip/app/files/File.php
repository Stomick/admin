<?php

namespace app\files;

/**
 * Base File class.
 */
class File extends \flexibuild\file\File
{
}
