<?php

Yii::setAlias('@app', dirname(__DIR__) . '/');
Yii::setAlias('@console', dirname(__DIR__) . '/console');
