<?php

return [
    'sms' => [
        'api_id' => 'DA03781E-9E70-8D31-5234-3B80E5182D21',
        'login' => '79164871795',
        'password' => 'WEEV20022017',
    ],
    'payment' => [
        'Merchant code' => 'trhythyu',
        'Secret key' => 'Gc]b?k=H8*O14Wx[e7[c',
    ],
    'adminEmail' => 'info@weev.ru',
];
