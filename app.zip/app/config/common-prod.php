
<?php

return [
    'components' => [
        'db' => [
            'enableSchemaCache' => true,
            'dsn' => 'mysql:host=localhost;dbname=weev',
            'username' => 'root',
            'password' => '22b158a7d43920ad',
        ],
    ],
];
