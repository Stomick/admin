<?php

return [
    'components' => [
        'db' => [
            'dsn' => 'mysql:host=localhost;dbname=weev',
            'username' => 'root',
            'password' => 'cbcntvf',
        ],
//        'mailer' => [
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
//            'useFileTransport' => false,
//            'transport' => [
//                'class' => 'Swift_SmtpTransport',
//                'host' => 'mailtrap.io',
//                'username' => '5526865f846587375',
//                'password' => '2c7e94a6940c2e',
//                'port' => 465,
//            ],
//        ],
    ],
];
