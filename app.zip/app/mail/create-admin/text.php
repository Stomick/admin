<?php
/* @var $this yii\web\View */
/* @var $model app\models\User */
/* @var  $password string */

?>
Дорогой <?= $model->name; ?>,
На LetMeSport для Вас был создан аккаунт администратора.

Login: <?= $model->email; ?>

Password: <?= $password; ?>


