<?php
namespace app\models\files;

use app\files\File;

/**
 * Class DocumentFile
 * @package app\models\files
 */
class DocumentFile extends File
{

}