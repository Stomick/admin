<?php
namespace app\models\files;

use app\files\File;

/**
 * Class RedactorImage
 * @package app\models\files
 */
class RedactorImage extends File
{

}
