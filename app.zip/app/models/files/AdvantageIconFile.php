<?php
namespace app\models\files;

use app\files\ImageFile;

/**
 * Class AdvantageIconFile
 * @package app\models\files
 */
class AdvantageIconFile extends ImageFile
{

}