<?php
namespace app\models\files;

use app\files\ImageFile;

/**
 * Class SportCenterLogoFile
 * @package app\models\files
 */
class SportCenterLogoFile extends ImageFile
{

}