<?php
namespace app\models\files;

use app\files\File;

/**
 * Class RedactorFile
 * @package app\models\files
 */
class RedactorFile extends File
{

}