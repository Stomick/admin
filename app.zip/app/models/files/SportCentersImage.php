<?php
namespace app\models\files;

use app\files\ImageFile;

/**
 * Class SportCentersImage
 * @package app\models\files
 */
class SportCentersImage extends ImageFile
{

}