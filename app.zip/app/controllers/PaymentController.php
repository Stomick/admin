<?php

namespace app\controllers;

use yii\web\Controller;
use Yii;
use app\models\Booking;
use app\base\components\PayU;
use yii\web\Response;
use app\models\Payment;
use yii\i18n\Formatter;

/**
 * Class AdvantageController
 * @package app\controllers
 */
class PaymentController extends Controller
{
    /**
     * @param Action $action
     * @return bool
     * @throws \yii\web\BadRequestHttpException
     */
    public function beforeAction($action)
    {
        if ($action->id === 'payment') {
            $this->enableCsrfValidation = false;
        }

        return parent::beforeAction($action);
    }

    /**
     * @param integer $id
     * @param null|string $answer
     */
    public function actionPayment($id = null, $answer = null)
    {

            $option = [
                'merchant' => Yii::$app->params['payment']['Merchant code'],
                'secretkey' => Yii::$app->params['payment']['Secret key'],
                'debug' => 0
            ];
            $booking = Booking::findOne($id);
            Yii::$app->response->format = Response::FORMAT_HTML;

            $f_name = explode(" ", $booking->user->name)[0];
            $l_name = explode(" ", $booking->user->name)[1];

            $formatter = new Formatter();
            $formatter->datetimeFormat = 'yyyy-MM-dd H:m:s';
            $formatter->timeZone = 'UTC';
            if ($booking) {
                // Create form for request
                $forSend = [
                    'MERCHANT' => Yii::$app->params['payment']['Merchant code'],
                    'ORDER_REF' => 1000 + $booking->id, // Uniqe order
                    'ORDER_DATE' => $formatter->asDatetime(time(), 'yyyy-MM-dd HH:mm:ss'),
                    'ORDER_PNAME' => Booking::getNameBooking($id), // Array with data of goods
                    'ORDER_PCODE' => 'booking ' . $booking->hour, // Array with codes of goods
                    //'ORDER_PINFO[]' => 'Оплата заказа на ' . $booking->year . '-' . $booking->month . '-' . $booking->day . ' ' . $booking->hour . ':00', // Array with additional data of goods
                    'ORDER_PRICE' => Booking::getPriceBooking($booking->id), // Array with prices of goods
                    'ORDER_QTY' => '1', // Array with data of counts of each goods
                    'ORDER_VAT' => '0', // Array with VAT of each goods
                    'PRICES_CURRENCY' => "RUB",  // Currency
                    'ORDER_HASH' => '',
                    'BACK_REF' => "http://api.weev.ru/payment/payment",
                    'BILL_FNAME' => $booking->user ? $f_name : null,
                    'BILL_LNAME' => $booking->user ? $l_name : null,
                    'BILL_BANKACCOUNT' => '',
                    //'BILL_EMAIL' => $booking->user ? $booking->user->email : null,
                    'BILL_EMAIL' => "biktimirova.alina@weev.ru",
                    'BILL_PHONE' => $booking->user ? $booking->user->phone : null,
                    'LANGUAGE' => "RU"
                    //'PAY_METHOD' => "CCVISAMC",
                    //'TESTORDER' => 'FALSE'
                ];
                // Create form
                if (!$answer) {
                    try{
                        $pay = PayU::getInst()->setOptions($option)->setData($forSend)->LU();
                        $script = "<script>
                        (function(){
                            document.addEventListener('DOMContentLoaded', function() {
                                var form = document.getElementById('pay-form');
                                form.submit();
                            });
                        })();
                    </script>";
                        print $pay . $script;
                    }catch (\Exception $e){
                        return $e->getMessage();
                    }
                }
            }

            $params = Yii::$app->request->get();

            if (isset($params['answer'])) {
                // Read answer (IPN)
                $payAnswer = PayU::getInst()->setOptions($option)->IPN();
                $payment = new Payment();
                $attributes = Yii::$app->request->post();

                $payment->setAttributes(array_change_key_case($attributes));
                $payment->save();

                $booking = Booking::findOne($payment->refnoext);

                if ($booking) {
                    $booking->submit = true;
                    $booking->save();
                }

                echo $payAnswer;
            }

            // Check for real BACK_REF
            // $pay true|false
            if (isset($params['ctrl'])) {
                $pay = PayU::getInst()->setOptions($option)->checkBackRef();

                echo $pay ? "Real request" : "Fake request";
            }
    }
}
