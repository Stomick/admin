<?php

namespace app\base\components;

use Yii;
use yii\base\Component;
use yii\i18n\Formatter;
use app\models\User;

/**
 * Class PayU
 * @property string $answer
 * @property array $dataArr
 * @property array $IPNcell
 * @property integer $debug
 * @property string $button
 * @property string $showinputs
 * @package app\base\components
 */
class PayU extends Component{

    /**
     *
     *
     */

    public $luUrl = "https://secure.payu.ru/order/lu.php";
    public $button = "<input type='submit'>";
    public $debug = 0;
    public $showinputs = "hidden";
    private static $Inst = false;
    private static $merchant;
    private static $key;
    private $data = [];
    private $dataArr = [];
    private $answer = "";
    private $LUcell = [
        'MERCHANT' => 1,
        'ORDER_REF' => 0,
        'ORDER_DATE' => 1,
        'ORDER_PNAME' => 1,
        'ORDER_PGROUP' => 0,
        'ORDER_PCODE' => 1,
        'ORDER_PINFO' => 0,
        'ORDER_PRICE' => 1,
        'ORDER_QTY' => 1,
        'ORDER_VAT' => 1,
        'PRICES_CURRENCY' => 1,
        'DISCOUNT' => 0,
        'PAY_METHOD' => 0,
        'TESTORDER' => 'FALSE',
        'ORDER_PRICE_TYPE' => 0
    ];
    private $IPNcell = [
        "IPN_PID",
        "IPN_PNAME",
        "IPN_DATE",
        "ORDERSTATUS"
    ];

    public function __toString()
    {
        return $this->answer === "" ? "<!-- Answer are not exists -->" : $this->answer;
    }

    public static function getInst()
    {
        if (self::$Inst === false) {
            self::$Inst = new PayU();
        }

        return self::$Inst;
    }
#---------------------------------------------
# Add all options for PayU object.
# Can change all public variables;
# $opt = array( merchant, secretkey, [ luUrl, debug, button ] );
#---------------------------------------------
    function setOptions($opt = [])
    {
        if (!isset($opt['merchant'])) {
            die("No params");
        }

        self::$merchant = $opt['merchant'];

        if (isset($opt['secretkey'])) {
            self::$key = $opt['secretkey'];
            unset($opt['secretkey']);
        }

        unset($opt['merchant']);

        if (count($opt) === 0) {
            return $this;
        }

        foreach ($opt as $k => $v) {
            $this->$k = $v;
        }

        return $this;
    }

    /**
     * @param array|null $array
     * @return $this
     */
    function setData($array = null)
    {
        if ($array === null) {
            die("No data");
        }

        $this->dataArr = $array;

        return $this;
    }

#--------------------------------------------------------
#	Generate HASH
#--------------------------------------------------------
    function Signature($data = null)
    {
        $hash ='';
        $hash .= isset($data['MERCHANT'])? mb_strlen($data['MERCHANT'], 'UTF-8') . $data['MERCHANT'] : "";
        $hash .= isset($data['ORDER_REF'])? mb_strlen($data['ORDER_REF'], 'UTF-8') . $data['ORDER_REF']: "";
        $hash .= isset($data['ORDER_DATE'])? mb_strlen($data['ORDER_DATE'], 'UTF-8') . $data['ORDER_DATE']: "";
        $hash .= isset($data['ORDER_PNAME'])? mb_strlen($data['ORDER_PNAME'], 'UTF-8') . $data['ORDER_PNAME']: "";
        $hash .= isset($data['ORDER_PINFO'])? mb_strlen($data['ORDER_PINFO'], 'UTF-8') . $data['ORDER_PINFO']: "";
        $hash .= isset($data['ORDER_PCODE'])? mb_strlen($data['ORDER_PCODE'], 'UTF-8') . $data['ORDER_PCODE'] : "";
        $hash .= isset($data['ORDER_PRICE'])? mb_strlen($data['ORDER_PRICE'], 'UTF-8') . $data['ORDER_PRICE']: "";
        $hash .= isset($data['ORDER_QTY'])? mb_strlen($data['ORDER_QTY'], 'UTF-8') . $data['ORDER_QTY']: "";
        $hash .= isset($data['ORDER_VAT'])? mb_strlen($data['ORDER_VAT'], 'UTF-8') . $data['ORDER_VAT']: "";
        $hash .= isset($data['ORDER_SHIPPING'])? mb_strlen($data['ORDER_SHIPPING'], 'UTF-8') . $data['ORDER_SHIPPING']: "";
        $hash .= isset($data['PAY_METHOD'])? mb_strlen($data['PAY_METHOD'], 'UTF-8') . $data['PAY_METHOD']: "";
        $hash .= isset($data['PRICES_CURRENCY'])? mb_strlen($data['PRICES_CURRENCY'], 'UTF-8') . $data['PRICES_CURRENCY']: "";
        /*$hash .= isset($data['BILL_FNAME'])? mb_strlen($data['BILL_FNAME'], 'UTF-8') . $data['BILL_FNAME']: "";
        $hash .= isset($data['BILL_LNAME'])? mb_strlen($data['BILL_LNAME'], 'UTF-8') . $data['BILL_LNAME']: "";
        if(isset($data['BILL_BANKACCOUNT'])) {
            if($data['BILL_BANKACCOUNT'] == ''){
                $hash .= '10';
            }else {
                $hash .= isset($data['BILL_BANKACCOUNT']) ? mb_strlen($data['BILL_BANKACCOUNT'], 'UTF-8') . $data['BILL_BANKACCOUNT'] : "";
            }
        }

        $hash .= isset($data['BILL_EMAIL'])? mb_strlen($data['BILL_EMAIL'], 'UTF-8') . $data['BILL_EMAIL']: "";
        $hash .= isset($data['BILL_PHONE'])? mb_strlen($data['BILL_PHONE'], 'UTF-8') . $data['BILL_PHONE']: "";
        $hash .= isset($data['LANGUAGE'])? mb_strlen($data['LANGUAGE'], 'UTF-8') . $data['LANGUAGE']: "";

        //$hash .= ($data['TESTORDER'] == 'TRUE' && isset($data['TESTORDER']))? mb_strlen($data['TESTORDER'], 'UTF-8') . $data['TESTORDER']: "";
        /*
        unset($data['MERCHANT'],
            $data['PRICES_CURRENCY'],
            $data['ORDER_SHIPPING'],
            $data['ORDER_VAT[]'],
            $data['ORDER_QTY[]'],
            $data['ORDER_PRICE[]'],
            $data['ORDER_PCODE[]'],
            $data['ORDER_PNAME[]'],
            $data['ORDER_DATE'],
            $data['ORDER_REF'],
            $data['ORDER_PINFO[]'],
            $data['PAY_METHOD']);
        if($data['TESTORDER'] == 'TRUE'){ unset($data['TESTORDER']);}
        /*
        $ignoredKeys = array(
            'AUTOMODE',
            'ORDER_HASH',
            'BACK_REF',
            'DEBUG',
            'DELIVERY_FNAME',
            'DELIVERY_LNAME',
            'DELIVERY_PHONE',
            'DELIVERY_ADDRESS',
            'DELIVERY_CITY',
            'LU_ENABLE_TOKEN',
            'LU_TOKEN_TYPE',
            'LANGUAGE'
        );

        ksort($data);
        foreach ($data as $dataKey => $dataValue) {
                if (!in_array($dataKey, $ignoredKeys, true)) {
                    $hash .= $this->convData($dataValue);
                }
        }
        */
        return hash_hmac("md5", $hash, self::$key);
    }

#--------------------------------------------------------
# Outputs a string for hmac format.
# For a string like 'aa' it will return '2aa'.
#--------------------------------------------------------
    private function convString($string)
    {
        return mb_strlen($string, '8bit') . $string;
    }

#--------------------------------------------------------
# The same as convString except that it receives
# an array of strings and returns the string from all values within the array.
#--------------------------------------------------------
    private function convArray($array)
    {
        $return = '';

        foreach ($array as $v) {
            $return .= $this->convString($v);
        }

        return $return;
    }

    private function convData($val)
    {
        return is_array($val) ? $this->convArray($val) : $this->convString($val);
    }
#----------------------------

#====================== LU GENERETE FORM =================================================
    public function LU()
    {
        //$arr['MERCHANT'] = self::$merchant;

        foreach($this->dataArr as $k => $v){
                $arr[$k] = $v;
        }

        $arr['ORDER_HASH'] = $this->Signature($arr);
        //$arr['TESTORDER'] = $this->debug == 1 ? "TRUE" : "FALSE";
        //$arr['DEBUG'] = $this->debug;
        $this->answer = $this->genereteForm($arr);

        return $this->answer;
    }

#-----------------------------
# Check array for correct data
#-----------------------------
    private function checkArray($data)
    {
        $ret = [];

        foreach ($this->LUcell as $k => $v) {
            if (isset($data[$k])) {
                $ret[$k] = $data[$k];
            } elseif ($v == 1) {
                die("$k is not set");
            }
        }

        return $ret;
    }

#-----------------------------
# Method which create a form
#-----------------------------
    private function genereteForm($data)
    {
        $form = '<form method="post" action="' . $this->luUrl . '" accept-charset="utf-8" id="pay-form">' . "\n";

        foreach ($data as $k => $v) {
            $form .= $this->makeString($k, $v);
        }

        return $form . "</form>";
    }

#-----------------------------
# Make inputs for form
#-----------------------------
    private function makeString($name, $val, $key = '')
    {
        $str = "";

        if (!is_array($val)) {
            return '<input type="' . $this->showinputs . '" name="' . $name . '" value="' . htmlspecialchars($val) .'" >' . "\n";
        }

        foreach ($val as $k => $v) {
            $str .= $this->makeString($name . '[]', $v , $k);
        }

        return $str;
    }
#======================= END LU =====================================

#======================= IPN READ ANSWER ============================
    public function IPN()
    {
        $arr = &$this->dataArr;
        $arr = Yii::$app->request->post();

        foreach ($this->IPNcell as $name) {
            if (!isset($arr[$name])) {
                die("Incorrect data");
            }
        }

        $hash = $arr["HASH"];

        unset($arr["HASH"]);

        $sign = $this->Signature($arr);

        if ($hash != $sign) {
            die("Incorrect hash");
        }

        $datetime = date("YmdHis");
        $sign = $this->Signature([
            "IPN_PID" => $arr["IPN_PID"][0],
            "IPN_PNAME" => $arr["IPN_PNAME"][0],
            "IPN_DATE" => $arr["IPN_DATE"],
            "DATE" => $datetime
        ]);
        $this->answer = "<!-- <EPAYMENT>$datetime|$sign</EPAYMENT> -->";

        return $this;
    }
#======================= END IPN ============================

#======================= Check BACK_REF =====================
    function checkBackRef($type = "http")
    {
        $path = $type . '://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
        $tmp = explode("?", $path);
        $url = $tmp[0] . '?';
        $params = [];

        foreach ($_GET as $k => $v) {
            if ($k != "ctrl") {
                $params[] = $k . '=' . rawurlencode($v);
            }
        }

        $url = $url . implode("&", $params);

        $arr = [$url];
        $sign = $this->Signature($arr);
        #echo "$sign === ".$_GET['ctrl'];
        $this->answer = $sign === $_GET['ctrl'] ? true : false;

        return $this->answer;
    }
#======================= END Check BACK_REF =================
    protected function hashPayoutData()
    {
        $hash = '';
        foreach ($this->dataArr as $k => $v){
            if(!is_array($v)) {
                $hash .= $v;
            }
            else{
                foreach ($v as $a => $b)
                    $hash .= $b;
            }
        }
        $hash .= self::$key;
        $hash = md5($hash);
        return $hash;
    }
}
