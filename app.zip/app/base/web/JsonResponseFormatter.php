<?php

namespace app\base\web;

/**
 * JsonResponseFormatter
 */
class JsonResponseFormatter extends \yii\web\JsonResponseFormatter
{
}
